export interface JwtModuleOptions {
  secretKey: string;
}
