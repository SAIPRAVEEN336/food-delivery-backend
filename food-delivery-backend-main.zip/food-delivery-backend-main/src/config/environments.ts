export const environments = {
  development: '.env.dev',
  production: '.env.prod',
  test: '.env.test',
};
