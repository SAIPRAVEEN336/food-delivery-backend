module.exports = {
  '*.+(ts|json)': ['eslint --fix', 'prettier --write'],
};
